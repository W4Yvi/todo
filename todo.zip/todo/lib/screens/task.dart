// task_screen.darts
import 'package:flutter/material.dart';
import 'search_screen.dart'; // Import the SearchScreen

class TasksScreen extends StatelessWidget {
  const TasksScreen({super.key});

  void _navigateToSearchScreen(BuildContext context) {
    // Navigate to SearchScreen
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => const SearchScreen()),
    );
  }

  void _addTask(BuildContext context) {
    // Show a custom dialog with a bottom slide animation
    showDialog(
      context: context,
      builder: (BuildContext context) {
        TextEditingController taskController = TextEditingController();

        return StatefulBuilder(
          builder: (context, setState) {
            // Animation Controller for sliding up the dialog
            final AnimationController _controller = AnimationController(
              duration: const Duration(milliseconds: 300),
              vsync: Navigator.of(context),
            );
            final Animation<Offset> _offsetAnimation = Tween<Offset>(
              begin: const Offset(0, 1), // Start position (bottom)
              end: Offset.zero, // End position (center)
            ).animate(CurvedAnimation(
              parent: _controller,
              curve: Curves.easeInOut,
            ));

            // Start the animation when the dialog is built
            _controller.forward();

            return Stack(
              children: [
                Positioned(
                  bottom: 30, // Change this to position the dialog vertically
                  left: 20, // Adjust the left position as needed
                  right: 20, // Adjust the right position as needed
                  child: AnimatedBuilder(
                    animation: _controller,
                    builder: (context, child) {
                      return SlideTransition(
                        position: _offsetAnimation,
                        child: Dialog(
                          shape: RoundedRectangleBorder(
                            borderRadius:
                                BorderRadius.circular(10.0), // Rounded corners
                          ),
                          child: Container(
                            width: 1000,
                            height: 100,
                            padding: const EdgeInsets.all(10.0),
                            child: Column(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                TextField(
                                  controller: taskController,
                                  decoration: const InputDecoration(
                                      hintText: 'Input new task here'),
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                ),
              ],
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Row(
          children: [
            Text(
              'Hi User!',
              style: TextStyle(
                color: Colors.black,
                fontSize: 24,
              ),
            ),
            Spacer(),
            IconButton(
              icon: const Icon(Icons.search, color: Colors.black),
              onPressed: () => _navigateToSearchScreen(context),
            ),
          ],
        ),
      ),
      body: const Column(
        children: [
          // Your content here
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addTask(context),
        backgroundColor: Colors.blue,
        child: const Icon(Icons.add),
      ),
    );
  }
}
